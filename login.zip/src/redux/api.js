export const baseUrl = {
    apiUrl: "http://localhost:3000"
};