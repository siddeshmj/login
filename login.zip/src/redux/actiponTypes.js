export const FETCH_USER = "FETCH_USER"
export const LOGIN_USER = "LOGIN_USER";
export const LOGIN_FAILURE = "LOGIN_FAILURE"