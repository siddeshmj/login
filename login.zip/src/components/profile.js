import React,{useState, useEffect} from 'react';
import axios from 'axios';

function Profile() {

const [dat, setDat] = useState([]);

const url = 'http://localhost:3000/user';
/*useEffect(() => {
  
fetch(url)
.then((response) => response.json())
.then((json) => setDat(json))
}, [])
*/
useEffect(() => {
    
axios.get('http://localhost:3000/user')
.then((response) => {
    console.log(response.data)
    setDat( response.data)
})
.catch(error => {console.log(error)})
console.log(dat)
},[])

console.log(dat)
          
    return (
        <div>
            
            <ul>
                {dat.map((data,id) =>
                <li key={id}>{data.id}</li>
                )}
                    

                </ul>
        </div>
    )
}

export default Profile
